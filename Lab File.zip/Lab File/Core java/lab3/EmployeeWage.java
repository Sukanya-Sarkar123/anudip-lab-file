package org.anudip.lab3;

import java.text.DecimalFormat;
import java.util.Scanner;

public class EmployeeWage {
	private static DecimalFormat decimalFormat = new DecimalFormat("0.00");

    public static String convertToTwoDecimalPlace(double value) {
        return decimalFormat.format(value);
    }

    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);
        try {
            int numWorkers;

            // Accept the number of workers at the site
            System.out.print("Enter the number of workers at the site (minimum 5): ");
            numWorkers = Integer.parseInt(scanner.nextLine());

            if (numWorkers < 5) {
                System.out.println("Wrong workers number. Program stopped.");
                return;
            }

            double totalWage = 0;

            for (int i = 0; i < numWorkers; i++) {
                // Accept the wage figure of each worker
                while (true) {
                    try {
                        System.out.print("Enter the daily wage of worker " + (i + 1) + ": ");
                        double wage = Double.parseDouble(scanner.nextLine());

                        if (wage < 100.00 || wage > 250.00) {
                            throw new WageException("WageException: Wage should be between 100.00 and 250.00");
                        }

                        totalWage += wage;
                        break;
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid input. Please enter a valid number.");
                    } catch (WageException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
            }

            // Calculate the average wage
            double averageWage = totalWage / numWorkers;

            // Display the total and average wage for the site
            System.out.println("Total wage expense: Rs." + convertToTwoDecimalPlace(totalWage));
            System.out.println("Average daily wage: Rs." + convertToTwoDecimalPlace(averageWage));

        } finally {
            System.out.println("Program is over.");
        }
    }

}
