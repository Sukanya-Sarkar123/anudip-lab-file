package org.anudip.lab3;

public class EssentialCommodityException extends RuntimeException{
	static final long serialVersionUID=1L;
	EssentialCommodityException(String message){
		super(message);
	}

}
