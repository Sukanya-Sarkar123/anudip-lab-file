package org.anudip.lab3;

public class WageException extends RuntimeException {
	public WageException(String message) {
        super(message);
	}

}
