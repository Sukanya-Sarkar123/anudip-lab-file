package org.anudip.lab3;

public class PriceException extends RuntimeException {
	static final long serialVersionUID=1L;
	public PriceException (String message){
		super(message);

}
}