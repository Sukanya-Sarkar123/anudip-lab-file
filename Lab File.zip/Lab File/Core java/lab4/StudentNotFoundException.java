package org.anudip.lab4;

public class StudentNotFoundException extends RuntimeException {
	
	public StudentNotFoundException(String message) {
        super(message);
	}
	

}
