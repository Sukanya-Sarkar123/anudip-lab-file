package org.anudip.mavenApplication.Lab2;

public class PermanentEmployee extends Employee{
	private Double monthlySalary;
    private Double pf;
    private Double tax;
    private static int idGen = 1000;

    public PermanentEmployee(String employeeName, String department, Double monthlySalary) {
        super(employeeName, department);
        this.monthlySalary = monthlySalary;
        this.pf = monthlySalary * 0.15;
        this.calculateTax();
        this.setEmployeeId(generateId());
    }

    @Override
    public void calculateTax() {
        tax = monthlySalary * 12 * 0.10;
    }

    @Override
    public String toString() {
        return String.format("%-15s %-20s %-15s %-15.2f %-15.2f %-15.2f",
                getEmployeeId(), getEmployeeName(), getDepartment(), monthlySalary, pf, tax);
    }

    public static String generateId() {
        return "P" + (++idGen);
    }

}



