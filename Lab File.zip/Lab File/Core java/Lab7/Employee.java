package org.anudip.mavenApplication.Lab2;

public class Employee implements Comparable<Employee>{
	private String employeeId;
    private String employeeName;
    private String department;

    public Employee(String employeeName, String department) {
        this.employeeName = employeeName;
        this.department = department;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getDepartment() {
        return department;
    }

    public void calculateTax() {
        // To be implemented in subclasses
    }

    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s", employeeId, employeeName, department);
    }

    @Override
    public int compareTo(Employee other) {
        return this.employeeId.compareTo(other.employeeId);
    }

}
	


