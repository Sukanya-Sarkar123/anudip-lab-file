package org.anudip.mavenApplication.Lab2;


public class ContractEmployee extends Employee{
	private Integer contractPeriod;
    private Double contractAmount;
    private Double tax;
    private static int idGenerator = 2000;

    public ContractEmployee(String employeeName, String department, Integer contractPeriod, Double contractAmount) {
        super(employeeName, department);
        this.contractPeriod = contractPeriod;
        this.contractAmount = contractAmount;
        this.calculateTax();
        this.setEmployeeId(generateId());
    }

    @Override
    public void calculateTax() {
        tax = contractAmount * 0.10;
    }

    @Override
    public String toString() {
        return String.format("%-15s %-20s %-15s %-15d %-15.2f %-15.2f",
                getEmployeeId(), getEmployeeName(), getDepartment(), contractPeriod, contractAmount, tax);
    }

    public static String generateId() {
        return "C" + (++idGenerator);
    
	
    }
}