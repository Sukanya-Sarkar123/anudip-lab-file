package org.anudip.mavenApplication.Lab2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter Number of Employees:");
	        int numberOfEmployees = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline character

	        List<Employee> permanentEmployees = new ArrayList<>();
	        List<Employee> contractEmployees = new ArrayList<>();

	        System.out.println("Enter all Employees details...");

	        for (int i = 0; i < numberOfEmployees; i++) {
	            String input = scanner.nextLine();
	            String[] details = input.split(",");

	            String name = details[0].trim();
	            String department = details[1].trim();

	            if (details.length == 3) {
	                Double salary = Double.parseDouble(details[2].trim());
	                PermanentEmployee permanentEmployee = new PermanentEmployee(name, department, salary);
	                permanentEmployees.add(permanentEmployee);
	            } else if (details.length == 4) {
	                Integer period = Integer.parseInt(details[2].trim());
	                Double amount = Double.parseDouble(details[3].trim());
	                ContractEmployee contractEmployee = new ContractEmployee(name, department, period, amount);
	                contractEmployees.add(contractEmployee);
	            }
	        }

	        Collections.sort(permanentEmployees);
	        Collections.sort(contractEmployees, Collections.reverseOrder());

	        System.out.println("\nPermanent Employee List\n");
	        System.out.printf("%-15s %-20s %-15s %-15s %-15s %-15s\n",
	                "Id", "Name", "Department", "Salary", "PF", "Tax");
	        for (Employee employee : permanentEmployees) {
	            System.out.println(employee);
	        }

	        System.out.println("\nContract Employee List\n");
	        System.out.printf("%-15s %-20s %-15s %-15s %-15s %-15s\n",
	                "Id", "Name", "Department", "Period", "Amount", "Tax");
	        for (Employee employee : contractEmployees) {
	            System.out.println(employee);
	        }
	}
}
