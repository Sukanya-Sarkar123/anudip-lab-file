package org.anudip.lab;

import java.util.Scanner;

public class SumofPrimes {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        if (size < 0) {
            System.out.println("Invalid Input");
            scanner.close();
            return;
        }

        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            arr[i] = scanner.nextInt();
        }
        scanner.close();

        int sumOfPrimes = 0;
        for (int num : arr) {
            if (isPrime(num)) {
                sumOfPrimes += num;
            }
        }

        if (sumOfPrimes == 0) {
            System.out.println("No");
        } else {
            System.out.println("Sum of prime numbers: " + sumOfPrimes);
        }
    }

    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
        
        
        
        
        
        
        
        


