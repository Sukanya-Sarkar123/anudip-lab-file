package org.anudip.lab;
public class Hello {
	
	static String splitDomainName(String str,
            String delimeter)
{
String finalOutput = "";
String arrayOfStr[] = str.split(delimeter);
if (arrayOfStr.length == 2) {
finalOutput = arrayOfStr[1];
}
return finalOutput;
}

public static void main(String args[])
{
//  Enter the Email as  String
String str = "team@geeksforgeeks.org";

// deleimeter
String deleimeter = "@";
System.out.println("The original string is :"
     + str);
System.out.println(
"The extracted domain name :"
+ splitDomainName(str, deleimeter));
}
}