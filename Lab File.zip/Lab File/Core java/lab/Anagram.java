package org.anudip.lab;

public class Anagram {

	public static boolean areAnagrams(String a, String b)
	{
	               //Removing blank spaces
	               String str1 = a.replaceAll("\\s", "");
	               String str2 = b.replaceAll("\\s", "");
	               
	              
	               //if lengths of strings are not equal, we are done.
	               if(str1.length() != str2.length())
	                               return false;
	               //Handling the case-insensitivity scenario
	               char[] arrStr1 = str1.toLowerCase().toCharArray();
	               char[] arrStr2 = str2.toLowerCase().toCharArray();
	               
	            
	               int[] arr1 = new int[65536];
	               int[] arr2 = new int[65536];
	              
	               
	               //storing key-value pair
	               for(int i = 0; i < arrStr1.length; i++)
	               {
	                               arr1[arrStr1[i]]++;
	                               arr2[arrStr2[i]]++; 
	                               
	                                
	               }
	               //comparing values of the integer arrays
	               for(int i = 0; i < 65536; i++)
	               {
	                               if(arr1[i] != arr2[i])
	                                              return false;
	               }
	               return true;
	}
	public static void main(String[] args)
	{
	               String s1 = "Silent and Listen", s2 = "Schoolmaster and The classroom";
	               if(areAnagrams(s1, s2))
	                               System.out.println("The given strings are anagrams of each other.");
	               else
	                               System.out.println("The given strings are not anagrams of each other.");
	}
	}