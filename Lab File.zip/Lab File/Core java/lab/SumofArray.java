package org.anudip.lab;

import java.util.Scanner;

public class SumofArray {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        if (size < 3) {
            System.out.println("Invalid Input");
        } else {
            int[] arr = new int[size];

            // Input elements into the array
            for (int i = 0; i < size; i++) {
                System.out.print("Enter element " + (i + 1) + ": ");
                int num = scanner.nextInt();

                if (num <= 0) {
                    System.out.println("Invalid Input");
                    return;
                }

                arr[i] = num;
            }

            // Calculate and print the sum of highest and lowest inputs
            int sum = findSumOfHighestAndLowest(arr);
            System.out.println("Sum of highest and lowest inputs: " + sum);
        }

        scanner.close();
    }

    public static int findSumOfHighestAndLowest(int[] arr) {
        int min = arr[0];
        int max = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
            if (arr[i] > max) {
                max = arr[i];
            }
        }

        return min + max;

}
}
