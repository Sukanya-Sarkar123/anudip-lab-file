package org.anudip.lab;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPAdressValidator {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter an Ip address:");
		String ip=scanner.nextLine();
		String regex =  "^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(ip);
		matcher.matches();
		if (matcher.matches()) 
		{
			System.out.println("valid");}
			else {
				System.out.println("Invalid");	
		                }

                 }

	}