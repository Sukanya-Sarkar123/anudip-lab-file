package org.anudip.mavenApplication.Lab3;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class UnixUserMain {
	private static Set<UnixUser> unixUsers = new LinkedHashSet<>();
    private static int nextUserId = 1001;

    public static boolean checkPrime(int no) {
        if (no <= 1) {
            return false;
        }
        if (no <= 3) {
            return true;
        }
        if (no % 2 == 0 || no % 3 == 0) {
            return false;
        }
        int i = 5;
        while (i * i <= no) {
            if (no % i == 0 || no % (i + 2) == 0) {
                return false;
            }
            i += 6;
        }
        return true;
    }

    public static void createUser(String input) {
        String[] userDetails = input.split(",");
        Integer employeeId = Integer.parseInt(userDetails[0]);
        String username = userDetails[1];
        String userType = userDetails[2];
        Integer userId = (userType.equals("Super") && checkPrime(nextUserId)) ? nextUserId++ : nextUserId++;

        UnixUser unixUser = new UnixUser(userId, employeeId, username, userType);
        unixUsers.add(unixUser);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of Unix users: ");
        int numUsers = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        for (int i = 0; i < numUsers; i++) {
            System.out.print("Enter user details (employee id, name, user type): ");
            String input = scanner.nextLine();
            createUser(input);
        }

        scanner.close();

        // Display user details in tabular format
        System.out.println("\nUser Details:");
        System.out.println(String.format("%-10s %-10s %-20s %-10s", "User ID", "Employee ID", "Username", "User Type"));
        for (UnixUser user : unixUsers) {
            System.out.println(user);
        }
    }
}