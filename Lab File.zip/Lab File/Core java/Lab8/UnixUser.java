package org.anudip.mavenApplication.Lab3;
import java.util.*;

public class UnixUser {
	private Integer userId;
    private Integer employeeId;
    private String username;
    private String userType;

    public UnixUser(Integer userId, Integer employeeId, String username, String userType) {
        this.userId = userId;
        this.employeeId = employeeId;
        this.username = username;
        this.userType = userType;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public String getUsername() {
        return username;
    }

    public String getUserType() {
        return userType;
    }

    @Override
    public String toString() {
        return String.format("%-10s %-10s %-20s %-10s", userId, employeeId, username, userType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        UnixUser otherUser = (UnixUser) obj;
        return Objects.equals(employeeId, otherUser.employeeId);
    }
}


