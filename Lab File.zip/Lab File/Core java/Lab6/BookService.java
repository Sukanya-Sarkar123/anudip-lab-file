package org.anudip.mavenApplication.Lab;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BookService {
	 public List<Book> arrangeBooksNumberWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        Collections.sort(sortedList, Comparator.comparing(Book::getBookNumber));
	        return sortedList;
	    }

	    public List<Book> arrangeBooksTitleWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        Collections.sort(sortedList, Comparator.comparing(Book::getBookTitle));
	        return sortedList;
	    }

	    public List<Book> arrangeBooksAuthorWise(List<Book> bookList) {
	        List<Book> sortedList = new ArrayList<>(bookList);
	        Collections.sort(sortedList, Comparator.comparing(Book::getAuthor));
	        return sortedList;
	    }
	}


