package org.anudip.mavenApplication.Lab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserApplication {
	 private static List<User> userList = new ArrayList<>();

	    public static void uploadToList() {
	    	try (BufferedReader reader = new BufferedReader(new FileReader("d:/UserMaster.txt"))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                if (parts.length == 2) {
	                    userList.add(new User(parts[0], parts[1]));
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    public static void main(String[] args) {
	        uploadToList();
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter user id: ");
	        String inputUserId = scanner.nextLine();

	        System.out.print("Enter password: ");
	        String inputPassword = scanner.nextLine();

	        boolean isValid = false;
	        for (User user : userList) {
	            if (user.getUserId().equals(inputUserId) && user.getPassword().equals(inputPassword)) {
	                isValid = true;
	                break;
	            }
	        }

	        if (isValid) {
	            System.out.println("Login successful!");
	        } else {
	            System.out.println("Invalid user id or password.");
	        }

	        scanner.close();
	    }
	}


