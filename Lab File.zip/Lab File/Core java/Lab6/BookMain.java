package org.anudip.mavenApplication.Lab;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookMain {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        BookService bookService=new BookService();
	        List<Book> books = Library.getAllBooks();

	        while (true) {
	            System.out.println("Menu");
	            System.out.println("1. Display Book Number-wise");
	            System.out.println("2. Display Book Title-wise");
	            System.out.println("3. Display Book Author-wise");
	            System.out.println("4. Exit");
	            System.out.print("Enter choice (1-4): ");
	            
	            int choice = scanner.nextInt();
	            List<Book> sortedBooks = new ArrayList<>();

	            switch (choice) {
	                case 1:
	                    sortedBooks = bookService.arrangeBooksNumberWise(books);
	                    break;
	                case 2:
	                    sortedBooks = bookService.arrangeBooksTitleWise(books);
	                    break;
	                case 3:
	                    sortedBooks = bookService.arrangeBooksAuthorWise(books);
	                    break;
	                case 4:
	                    System.out.println("Exiting program.");
	                    scanner.close();
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please select a valid option.");
	                    continue;
	            }

	            System.out.println("Book Number  Book Title                       Author            ");
	            System.out.println("------------------------------------------------------------");
	            for (Book book : sortedBooks) {
	                System.out.println(book);
	            }
	        }
	    }
	}


