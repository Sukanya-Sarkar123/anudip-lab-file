package org.anudip.mavenApplication.Lab;

import java.util.ArrayList;
import java.util.List;

public class Library {
	
	 private static List<Book> bookList = new ArrayList<>();

	    static {
	        bookList.add(new Book(3, "  Book   C","Author 3"));
	        bookList.add(new Book(1, "  Book   A","Author 1"));
	        bookList.add(new Book(2, "  Book   B","Author 2"));
	        bookList.add(new Book(6, "  Book   F","Author 2"));
	        bookList.add(new Book(4, "  Book   D","Author 3"));
	        bookList.add(new Book(5, "  Book   E","Author 1"));
	    }

	    public static List<Book> getAllBooks() {
	        return bookList;
	    }
	}

