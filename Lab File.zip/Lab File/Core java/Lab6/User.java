package org.anudip.mavenApplication.Lab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class User {
	 private String userId;
	    private String password;

	    public User() {
	    }

	    public User(String userId, String password) {
	        this.userId = userId;
	        this.password = password;
	    }

	    // Getters and setters

	    public String getUserId() {
	        return userId;
	    }

	    public void setUserId(String userId) {
	        this.userId = userId;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }
	}



