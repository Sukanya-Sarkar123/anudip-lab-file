package org.anudip.labApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabAppApplication.class, args);
	}

}

