package org.anudip.Lab2.bean;

public class Result {
    private String rollNumber;
    private Double halfYearlyTotal;
    private Double annualTotal;
    private String grade;

    public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal, String grade) {
        this.rollNumber = rollNumber;
        this.halfYearlyTotal = halfYearlyTotal;
        this.annualTotal = annualTotal;
        this.grade = grade;
    }

    

    public String getRollNumber() {
		return rollNumber;
	}



	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}



	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}



	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}



	public Double getAnnualTotal() {
		return annualTotal;
	}



	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}



	public String getGrade() {
		return grade;
	}



	public void setGrade(String grade) {
		this.grade = grade;
	}



	@Override
    public String toString() {
        return String.format("%-5s %-20s %-20s %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
    }
}