package org.anudip.Lab2.bean;

public class ResultService {
    public static String gradeCalculation(Result result) {
        // Calculate the percentage using the formula
        double percentage = ((result.getHalfYearlyTotal() + result.getAnnualTotal()) / 1000.0) * 100;

        // Determine the grade based on the percentage
        String grade;
        if (percentage >= 90) {
            grade = "E";
        } else if (percentage >= 75 && percentage < 90) {
            grade = "V";
        } else if (percentage >= 60 && percentage < 75) {
            grade = "G";
        } else if (percentage >= 45 && percentage < 60) {
            grade = "P";
        } else {
            grade = "F";
        }

        return grade;
    }
}