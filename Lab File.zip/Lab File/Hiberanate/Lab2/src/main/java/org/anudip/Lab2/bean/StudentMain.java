package org.anudip.Lab2.bean;

import java.util.Scanner;

public class StudentMain {
    public static void insertRecord() {
        // Logic to store new student's records including roll, name, semester, and half-yearly marks in respective tables
    }

    public static void updateRecord() {
        // Logic to update a student's record with annual exam marks and calculate the grade
    }

    public static void displayRecord() {
        // Logic to display a student's details and result details
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Student Entry");
            System.out.println("2. Result Update");
            System.out.println("3. Show Student");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    insertRecord();
                    break;
                case 2:
                    updateRecord();
                    break;
                case 3:
                    displayRecord();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}