package org.anudip.Lab2.bean;

public class Student {
    private String rollNumber;
    private String studentName;
    private String semester;

    public Student(String rollNumber, String studentName, String semester) {
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.semester = semester;
    }

    

    public String getRollNumber() {
		return rollNumber;
	}



	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}



	public String getStudentName() {
		return studentName;
	}



	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}



	public String getSemester() {
		return semester;
	}



	public void setSemester(String semester) {
		this.semester = semester;
	}



	@Override
    public String toString() {
        return String.format("%-5s %-20s %-5s", rollNumber, studentName, semester);
    }
}
