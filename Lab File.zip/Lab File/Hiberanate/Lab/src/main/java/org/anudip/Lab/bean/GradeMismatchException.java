package org.anudip.Lab.bean;

class GradeMismatchException extends RuntimeException {
    public GradeMismatchException(String message) {
        super(message);
    }
}
