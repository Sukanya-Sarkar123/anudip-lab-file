package org.anudip.Lab.bean;

class PriceException extends RuntimeException {
    public PriceException(String message) {
        super(message);
    }
}