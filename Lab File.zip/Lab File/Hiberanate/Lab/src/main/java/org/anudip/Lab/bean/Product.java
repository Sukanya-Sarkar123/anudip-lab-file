package org.anudip.Lab.bean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Product")
class Product implements Comparable<Product> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Product_Id")
    private Integer productId;
    
    @Column(name = "product_name")
    private String productName;
    
    @Column(name = "purchase_price")
    private Double purchasedPrice;
    
    @Column(name = "sales_price")
    private Double salesPrice;
    
    @Column(name = "grade")
    private String grade;

    public Product() {
    }

    public Product(String productName, Double purchasedPrice, Double salesPrice, String grade) {
        this.productName = productName;
        this.purchasedPrice = purchasedPrice;
        this.salesPrice = salesPrice;
        this.grade = grade;
    }

    // Getter and Setter methods

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s %-5s", productId, productName, purchasedPrice, salesPrice, grade);
    }

    @Override
    public int compareTo(Product o) {
        return this.productId.compareTo(o.productId);
    }
}