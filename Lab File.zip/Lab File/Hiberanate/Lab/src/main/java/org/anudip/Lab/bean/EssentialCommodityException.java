package org.anudip.Lab.bean;

class EssentialCommodityException extends RuntimeException {
    public EssentialCommodityException(String message) {
        super(message);
    }
}