package org.anudip.Lab.bean;

import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class ProductShow {

	public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml"); // Use your Hibernate configuration file

        SessionFactory sessionFactory = cfg.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();

        // Fetch products from the database and sort them
        List<Product> products = session.createQuery("FROM Product", Product.class).list();
        Collections.sort(products);

        // Display products in ascending order of product ID
        for (Product product : products) {
            System.out.println(product);
        }

        transaction.commit();
        session.close();
        sessionFactory.close();
    }
}
